Omer - Android TV launcher
1) افتح المجلد في Android Studio (Hedgehog أو أحدث)، انتظر مزامنة Gradle.
2) Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
3) على التلفزيون: فعّل Developer options + USB/Network debugging ثم:
   adb connect <TV-IP>:5555 && adb install app-debug.apk
