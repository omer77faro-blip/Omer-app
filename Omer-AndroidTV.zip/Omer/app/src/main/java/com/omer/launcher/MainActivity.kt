package com.omer.launcher

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.*
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class Item(val id: String, val label: String, val icon: Drawable?, val onClick: () -> Unit, val onLong: () -> Unit)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("omer", MODE_PRIVATE) }
    private lateinit var root: FrameLayout
    private lateinit var appsAdapter: ItemAdapter
    private lateinit var chAdapter: ItemAdapter

    // القوالب الجاهزة: الاسم، لون البداية، لون النهاية
    private val templates = listOf(
        Triple("ليلي", "#0F2027", "#2C5364"), Triple("أزرق", "#1A237E", "#3D5AFE"),
        Triple("غروب", "#42275A", "#E65100"), Triple("أخضر", "#0B3D2E", "#2E7D32"),
        Triple("أسود", "#000000", "#212121"))

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        root = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(48), dp(32), dp(48), dp(16)) }
        root.addView(col)
        col.addView(TextView(this).apply { text = "Omer"; textSize = 36f; setTextColor(Color.WHITE) })

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(btn("القوالب") { pickTemplate() })
        bar.addView(btn("لون مخصص") { customColor() })
        bar.addView(btn("إضافة قناة") { addChannel() })
        col.addView(bar)

        col.addView(title("القنوات"))
        chAdapter = ItemAdapter(emptyList()); col.addView(row(chAdapter))
        col.addView(title("التطبيقات"))
        appsAdapter = ItemAdapter(emptyList()); col.addView(row(appsAdapter))
        setContentView(root)
        applyBackground()
    }

    override fun onResume() { super.onResume(); loadApps(); loadChannels() }
    @Deprecated("Deprecated") override fun onBackPressed() {} // الشاشة الرئيسية لا تُغلق

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun title(t: String) = TextView(this).apply { text = t; textSize = 20f; setTextColor(Color.WHITE); setPadding(0, dp(20), 0, dp(8)) }
    private fun row(a: ItemAdapter) = RecyclerView(this).apply {
        layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false); adapter = a
        clipToPadding = false; setPadding(0, dp(6), 0, dp(6)); layoutParams = LinearLayout.LayoutParams(-1, dp(150))
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    // ---------- الخلفية ----------
    private fun applyBackground() {
        val c1 = Color.parseColor(prefs.getString("c1", templates[0].second))
        val c2 = Color.parseColor(prefs.getString("c2", templates[0].third))
        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
    }
    private fun pickTemplate() {
        AlertDialog.Builder(this).setTitle("اختر قالباً").setItems(templates.map { it.first }.toTypedArray()) { _, i ->
            prefs.edit().putString("c1", templates[i].second).putString("c2", templates[i].third).apply(); applyBackground()
        }.show()
    }
    private fun customColor() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val a = EditText(this).apply { hint = "#RRGGBB اللون الأول"; setText(prefs.getString("c1", "#0F2027")) }
        val b = EditText(this).apply { hint = "#RRGGBB اللون الثاني"; setText(prefs.getString("c2", "#2C5364")) }
        l.addView(a); l.addView(b)
        AlertDialog.Builder(this).setTitle("لون مخصص").setView(l).setPositiveButton("حفظ") { _, _ ->
            try {
                Color.parseColor(a.text.toString()); Color.parseColor(b.text.toString())
                prefs.edit().putString("c1", a.text.toString()).putString("c2", b.text.toString()).apply(); applyBackground()
            } catch (e: Exception) { Toast.makeText(this, "لون غير صالح", Toast.LENGTH_SHORT).show() }
        }.setNegativeButton("إلغاء", null).show()
    }

    // ---------- التطبيقات ----------
    private fun loadApps() {
        val pm = packageManager
        val found = LinkedHashMap<String, Pair<String, Drawable>>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (r in pm.queryIntentActivities(i, 0)) {
                val p = r.activityInfo.packageName
                if (p != packageName && p !in found) found[p] = Pair(r.loadLabel(pm).toString(), r.loadIcon(pm))
            }
        }
        val order = (prefs.getString("apps_order", "") ?: "").split(",").filter { it.isNotEmpty() }
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val ids = found.keys.filter { it !in hidden }.sortedWith(compareBy({ order.indexOf(it).let { x -> if (x < 0) Int.MAX_VALUE else x } }, { found[it]!!.first }))
        appsAdapter.items = ids.map { p ->
            Item(p, found[p]!!.first, found[p]!!.second, {
                (pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p))?.let { startActivity(it) }
            }, { editMenu(ids, p, { saveOrder(it) }, { hide(p) }) })
        }
        appsAdapter.notifyDataSetChanged()
    }
    private fun saveOrder(l: List<String>) { prefs.edit().putString("apps_order", l.joinToString(",")).apply(); loadApps() }
    private fun hide(p: String) { prefs.edit().putStringSet("hidden", (prefs.getStringSet("hidden", emptySet()) ?: emptySet()) + p).apply(); loadApps() }

    // ---------- القنوات ----------
    private fun channels(): MutableList<Pair<String, String>> =
        (prefs.getString("channels", "") ?: "").split("\n").filter { it.contains("|") }.map { it.substringBefore("|") to it.substringAfter("|") }.toMutableList()
    private fun saveChannels(l: List<Pair<String, String>>) { prefs.edit().putString("channels", l.joinToString("\n") { "${it.first}|${it.second}" }).apply(); loadChannels() }
    private fun loadChannels() {
        val list = channels()
        chAdapter.items = list.mapIndexed { idx, (name, target) ->
            Item(idx.toString(), name, null, { openTarget(target) }, {
                editMenu(list.indices.map { it.toString() }, idx.toString(), { ids ->
                    saveChannels(ids.map { list[it.toInt()] })
                }, { saveChannels(list.filterIndexed { i, _ -> i != idx }) }, "حذف")
            })
        }
        chAdapter.notifyDataSetChanged()
    }
    private fun openTarget(t: String) {
        try {
            if (t.contains("://")) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(t)))
            else packageManager.let { (it.getLeanbackLaunchIntentForPackage(t) ?: it.getLaunchIntentForPackage(t))?.let { i -> startActivity(i) } }
        } catch (e: Exception) { Toast.makeText(this, "تعذّر الفتح", Toast.LENGTH_SHORT).show() }
    }
    private fun addChannel() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val n = EditText(this).apply { hint = "اسم القناة" }
        val u = EditText(this).apply { hint = "رابط https://... أو اسم حزمة التطبيق" }
        l.addView(n); l.addView(u)
        AlertDialog.Builder(this).setTitle("إضافة قناة").setView(l).setPositiveButton("إضافة") { _, _ ->
            if (n.text.isNotBlank() && u.text.isNotBlank()) saveChannels(channels().apply { add(n.text.toString().trim() to u.text.toString().trim()) })
        }.setNegativeButton("إلغاء", null).show()
    }

    // ---------- ترتيب العناصر (ضغطة مطوّلة) ----------
    private fun editMenu(ids: List<String>, id: String, save: (List<String>) -> Unit, remove: () -> Unit, removeLabel: String = "إخفاء") {
        val i = ids.indexOf(id)
        AlertDialog.Builder(this).setItems(arrayOf("نقل لليسار", "نقل لليمين", removeLabel)) { _, w ->
            val m = ids.toMutableList()
            when (w) {
                0 -> if (i > 0) { m[i] = m[i - 1].also { m[i - 1] = m[i] }; save(m) }
                1 -> if (i < m.size - 1) { m[i] = m[i + 1].also { m[i + 1] = m[i] }; save(m) }
                2 -> remove()
            }
        }.show()
    }

    // ---------- المحوّل ----------
    inner class ItemAdapter(var items: List<Item>) : RecyclerView.Adapter<ItemAdapter.VH>() {
        inner class VH(val v: LinearLayout, val img: ImageView, val tv: TextView) : RecyclerView.ViewHolder(v)
        override fun onCreateViewHolder(p: android.view.ViewGroup, t: Int): VH {
            val v = LinearLayout(p.context).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isFocusable = true; isClickable = true
                layoutParams = RecyclerView.LayoutParams(dp(130), dp(130)).apply { setMargins(dp(6), 0, dp(6), 0) }
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_focused), GradientDrawable().apply { setColor(0x44FFFFFF); setStroke(dp(3), Color.WHITE); cornerRadius = dp(12).toFloat() })
                    addState(intArrayOf(), GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = dp(12).toFloat() })
                }
            }
            val img = ImageView(p.context).apply { layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)) }
            val tv = TextView(p.context).apply { setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; maxLines = 1; setPadding(dp(4), dp(6), dp(4), 0) }
            v.addView(img); v.addView(tv); return VH(v, img, tv)
        }
        override fun onBindViewHolder(h: VH, pos: Int) {
            val it = items[pos]; h.tv.text = it.label
            h.img.setImageDrawable(it.icon ?: GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#3D5AFE")) })
            h.v.setOnClickListener { it.onClick() }; h.v.setOnLongClickListener { _ -> it.onLong(); true }
        }
        override fun getItemCount() = items.size
    }
}
